What is this folder:
 -This folder is a collection of all Minecraft structures

How to install:
 1.Extract this zip
 2.Install WorldEdit mod for minecraft
 3.Navigate to your ".minecraft" folder
 4.Open "Config" folder
 5.Open "worldedit" folder
 6.Open "schematics" folder
 7.Copy paste all files (except this one) into that folder